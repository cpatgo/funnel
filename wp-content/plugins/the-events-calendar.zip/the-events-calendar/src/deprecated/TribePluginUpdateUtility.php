<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__PUE__Plugin_Info' );


	class TribePluginUpdateUtility extends Tribe__Events__PUE__Utility {

	}