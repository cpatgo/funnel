<?php

require_once awebdesk_classes("select.php");
require_once adesk_admin("functions/campaign.post.php");
require_once adesk_admin("functions/campaign.select.php");
require_once adesk_admin("functions/campaign.send.php");
require_once adesk_admin("functions/campaign.debug.php");
require_once adesk_admin("functions/campaign.save.php");

?>
