/* Environment settings for videoJS */
videojs.options.flash.swf = 'https://s3.amazonaws.com/template-resources/2.0/swf/video-js.swf';
VideoJS = videojs;
_V_ = VideoJS;