$(function () {
	$('body').addClass('clsWso_bg');
});
