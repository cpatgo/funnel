<?php
require_once(awebdesk('deskrecord/DeskRecord.class.php'));
class GlobalAuth extends DeskRecord{}
?>
